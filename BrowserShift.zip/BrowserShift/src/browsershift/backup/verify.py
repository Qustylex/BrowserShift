import hashlib
import json
from dataclasses import dataclass
from pathlib import Path


@dataclass
class VerifyResult:
    ok: bool
    file_count: int
    message: str = ""


def verify_backup(backup_path: Path) -> VerifyResult:
    mf = backup_path / "manifest.json"
    if not mf.is_file():
        return VerifyResult(False, 0, "manifest.json missing")
    try:
        manifest = json.loads(mf.read_text(encoding="utf-8"))
    except Exception as exc:
        return VerifyResult(False, 0, f"invalid manifest: {exc}")
    files = manifest.get("files", [])
    for entry in files:
        name = entry.get("name")
        expected = entry.get("sha256")
        if not name or not expected:
            return VerifyResult(False, len(files), "invalid entry")
        f = backup_path / name
        if not f.is_file():
            return VerifyResult(False, len(files), f"missing: {name}")
        if _sha256(f) != expected:
            return VerifyResult(False, len(files), f"hash mismatch: {name}")
    return VerifyResult(True, len(files))


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()