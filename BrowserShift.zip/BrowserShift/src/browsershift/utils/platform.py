import os
import platform
from enum import Enum
from pathlib import Path


class OS(Enum):
    WINDOWS = "windows"
    LINUX = "linux"
    MACOS = "macos"
    UNKNOWN = "unknown"


def detect_os() -> OS:
    s = platform.system().lower()
    if s == "windows":
        return OS.WINDOWS
    if s == "darwin":
        return OS.MACOS
    if s == "linux":
        return OS.LINUX
    return OS.UNKNOWN


CURRENT_OS = detect_os()


def is_windows() -> bool:
    return CURRENT_OS is OS.WINDOWS


def is_linux() -> bool:
    return CURRENT_OS is OS.LINUX


def is_macos() -> bool:
    return CURRENT_OS is OS.MACOS


def home() -> Path:
    return Path.home()


def windows_local_appdata() -> Path:
    v = os.environ.get("LOCALAPPDATA")
    return Path(v) if v else home() / "AppData" / "Local"


def windows_roaming_appdata() -> Path:
    v = os.environ.get("APPDATA")
    return Path(v) if v else home() / "AppData" / "Roaming"


def linux_config_home() -> Path:
    v = os.environ.get("XDG_CONFIG_HOME")
    return Path(v) if v else home() / ".config"


def linux_data_home() -> Path:
    v = os.environ.get("XDG_DATA_HOME")
    return Path(v) if v else home() / ".local" / "share"


def macos_app_support() -> Path:
    return home() / "Library" / "Application Support"


def config_root() -> Path:
    if CURRENT_OS is OS.WINDOWS:
        return windows_local_appdata()
    if CURRENT_OS is OS.MACOS:
        return macos_app_support()
    if CURRENT_OS is OS.LINUX:
        return linux_config_home()
    return home()


def roaming_root() -> Path:
    if CURRENT_OS is OS.WINDOWS:
        return windows_roaming_appdata()
    if CURRENT_OS is OS.MACOS:
        return macos_app_support()
    if CURRENT_OS is OS.LINUX:
        return linux_config_home()
    return home()


def app_data_root() -> Path:
    if CURRENT_OS is OS.WINDOWS:
        return windows_local_appdata() / "BrowserShift"
    if CURRENT_OS is OS.MACOS:
        return macos_app_support() / "BrowserShift"
    if CURRENT_OS is OS.LINUX:
        return linux_data_home() / "BrowserShift"
    return home() / ".browsershift"


def platform_label() -> str:
    if CURRENT_OS is OS.WINDOWS:
        return "Windows"
    if CURRENT_OS is OS.LINUX:
        return "Linux"
    if CURRENT_OS is OS.MACOS:
        return "macOS"
    return "Unknown"