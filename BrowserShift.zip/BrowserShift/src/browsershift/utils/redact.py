SENSITIVE = {
    "cookie", "cookies", "token", "password", "authorization",
    "session", "secret", "apikey", "api_key", "bearer",
}


def is_sensitive(key: str) -> bool:
    return any(s in key.lower() for s in SENSITIVE)


def redact(value: str | None) -> str:
    if not value:
        return ""
    if len(value) <= 4:
        return "***"
    return f"{value[:2]}***{value[-2:]}"