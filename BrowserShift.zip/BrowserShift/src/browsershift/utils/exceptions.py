class BrowserShiftError(Exception):
    pass


class BrowserNotDetectedError(BrowserShiftError):
    pass


class ProfileLockedError(BrowserShiftError):
    pass


class MigrationError(BrowserShiftError):
    pass


class BackupError(BrowserShiftError):
    pass


class UnsupportedOperationError(BrowserShiftError):
    pass


class CancelledError(BrowserShiftError):
    pass