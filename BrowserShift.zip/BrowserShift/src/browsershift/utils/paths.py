from pathlib import Path
from .platform import app_data_root


def app_data_dir() -> Path:
    base = app_data_root()
    base.mkdir(parents=True, exist_ok=True)
    return base


def backups_dir() -> Path:
    p = app_data_dir() / "backups"
    p.mkdir(parents=True, exist_ok=True)
    return p


def logs_dir() -> Path:
    p = app_data_dir() / "logs"
    p.mkdir(parents=True, exist_ok=True)
    return p