from rich.align import Align
from rich.panel import Panel
from rich.text import Text
from rich.table import Table
from rich.rule import Rule

from .theme import LOGO, PURPLE, PURPLE_LIGHT, WHITE, MUTED, SUCCESS, WARNING, ERROR


def banner():
    t = Text()
    t.append(LOGO, style=f"bold {PURPLE}")
    t.append("\n   Switch browsers. Keep your flow.\n", style=WHITE)
    t.append("   Terminal edition. Local. Private. Yours.\n", style=MUTED)
    return Panel(
        Align.center(t),
        border_style=PURPLE,
        title="[brand.light]BrowserShift[/]",
        subtitle="[muted]v0.3.0[/]",
        padding=(1, 2),
    )


def section(title):
    return Rule(title=f"[brand.light]{title}[/]", style=PURPLE)


def browser_table(browsers):
    tb = Table(
        show_header=True, header_style="brand.light",
        border_style=PURPLE, title="Detected browsers", title_style="brand",
    )
    tb.add_column("#", justify="right", style=MUTED, width=3)
    tb.add_column("Browser", style=WHITE)
    tb.add_column("Profiles", justify="right", style=PURPLE_LIGHT)
    tb.add_column("Default", style=MUTED)
    tb.add_column("Root path", style=MUTED, overflow="fold")
    for i, b in enumerate(browsers, 1):
        d = next((p.name for p in b.profiles if p.is_default), "-")
        tb.add_row(str(i), b.name, str(len(b.profiles)), d, str(b.profile_root))
    return tb


def profile_table(browser):
    tb = Table(
        show_header=True, header_style="brand.light",
        border_style=PURPLE, title=f"{browser.name} profiles", title_style="brand",
    )
    tb.add_column("#", justify="right", style=MUTED, width=3)
    tb.add_column("Name", style=WHITE)
    tb.add_column("Default", justify="center", style=SUCCESS)
    tb.add_column("Path", style=MUTED, overflow="fold")
    for i, p in enumerate(browser.profiles, 1):
        tb.add_row(str(i), p.name, "yes" if p.is_default else "", str(p.path))
    return tb


def category_table(categories, caps):
    tb = Table(
        show_header=True, header_style="brand.light",
        border_style=PURPLE, title="Categories", title_style="brand",
    )
    tb.add_column("#", justify="right", style=MUTED, width=3)
    tb.add_column("Category", style=WHITE)
    tb.add_column("Status", style=PURPLE_LIGHT)
    for i, c in enumerate(categories, 1):
        cap = caps.get(c)
        s = cap.value if cap else "unknown"
        color = {
            "supported": SUCCESS, "partial": WARNING,
            "unsupported": ERROR, "not_tested": MUTED,
        }.get(s, MUTED)
        tb.add_row(str(i), c.value, f"[{color}]{s}[/]")
    return tb