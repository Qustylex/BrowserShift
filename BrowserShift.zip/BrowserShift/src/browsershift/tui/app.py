import threading
import time

from rich.align import Align
from rich.console import Group
from rich.live import Live
from rich.panel import Panel
from rich.prompt import Prompt, IntPrompt, Confirm
from rich.text import Text

from .. import __version__
from ..browsers import detect_all
from ..browsers.base import Category
from ..browsers.detector import build_adapters
from ..core.plan import MigrationPlan
from ..core.orchestrator import run_migration
from ..core.progress import ProgressEngine
from ..utils.paths import backups_dir
from ..utils.platform import platform_label
from ..utils.exceptions import CancelledError, BrowserShiftError

from .theme import make_console, PURPLE, PURPLE_LIGHT, WHITE, MUTED, SUCCESS, WARNING, ERROR
from .render import banner, section, browser_table, profile_table, category_table


console = make_console()


def run():
    _clear()
    _splash()
    _clear()

    console.print(banner())
    console.print()

    console.print(section("Environment"))
    console.print(f"  Platform: [brand.light]{platform_label()}[/]")
    console.print(f"  Python:   [brand.light]{__import__('sys').version.split()[0]}[/]")
    console.print(f"  Backups:  [muted]{backups_dir()}[/]")
    console.print()

    with console.status("[brand]Scanning installed browsers...[/]", spinner="dots12"):
        browsers = detect_all()
        time.sleep(0.3)

    if not browsers:
        console.print(Panel(
            "No supported browsers were detected on this system.\n"
            "Install Chrome, Edge, Brave, Vivaldi, Opera, Opera GX, or Firefox and retry.",
            border_style=ERROR, title="[error]Nothing to migrate[/]",
        ))
        return 1

    console.print(browser_table(browsers))
    console.print()

    if not Confirm.ask("[brand.light]Start a new migration?[/]", default=True):
        console.print("[muted]Nothing to do. Goodbye.[/]")
        return 0

    src_b, src_p = _pick(browsers, "Source")
    dst_b, dst_p = _pick(browsers, "Destination")

    if src_b.id == dst_b.id and src_p.id == dst_p.id:
        console.print(Panel("Source and destination are the same profile.",
                            border_style=ERROR, title="[error]Invalid selection[/]"))
        return 1

    src_a = next(a for a in build_adapters() if a.id == src_b.id)
    dst_a = next(a for a in build_adapters() if a.id == dst_b.id)

    available = [c for c in Category if dst_a.capabilities().get(c).value in ("supported", "partial")]

    console.print(section("Categories"))
    console.print(category_table(list(Category), dst_a.capabilities()))
    console.print()

    chosen = _pick_categories(available)
    if not chosen:
        console.print("[warning]No categories selected. Aborting.[/]")
        return 1

    plan = MigrationPlan(
        source_browser_id=src_b.id, source_browser_name=src_b.name,
        source_profile=src_p,
        destination_browser_id=dst_b.id, destination_browser_name=dst_b.name,
        destination_profile=dst_p,
        categories=chosen,
    )

    console.print(section("Confirm"))
    console.print(f"  From : [brand.light]{src_b.name}[/] -> [muted]{src_p.path}[/]")
    console.print(f"  To   : [brand.light]{dst_b.name}[/] -> [muted]{dst_p.path}[/]")
    console.print(f"  Items: [brand.light]{', '.join(c.value for c in chosen)}[/]")
    console.print(f"  Backup: [muted]{backups_dir()}[/]")
    console.print()

    if not Confirm.ask("[brand.light]Proceed with migration?[/]", default=True):
        console.print("[muted]Cancelled by user.[/]")
        return 0

    report = _run(plan, src_a, dst_a)
    console.print()
    console.print(_finale(report))
    console.print()
    return 0


def _run(plan, src_a, dst_a):
    from rich.progress import (
        Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn,
    )

    live_items = []

    def on_event(payload):
        if payload.get("kind") == "item":
            live_items.append(payload["message"])
            if len(live_items) > 8:
                live_items.pop(0)

    engine = ProgressEngine(on_event=on_event)

    progress = Progress(
        SpinnerColumn(style=PURPLE),
        TextColumn("[brand.light]{task.description}"),
        BarColumn(complete_style=PURPLE, finished_style=SUCCESS, pulse_style=PURPLE_LIGHT),
        TextColumn("[value]{task.percentage:>5.1f}%[/]"),
        TextColumn("[muted]imp[/] [success]{task.fields[imported]}[/]"),
        TextColumn("[muted]skp[/] [warning]{task.fields[skipped]}[/]"),
        TextColumn("[muted]err[/] [error]{task.fields[failed]}[/]"),
        TimeElapsedColumn(),
    )

    t_backup = progress.add_task("backup", total=1, imported=0, skipped=0, failed=0)
    t_bm = progress.add_task("bookmarks", total=1, imported=0, skipped=0, failed=0)
    t_hist = progress.add_task("history", total=1, imported=0, skipped=0, failed=0)
    t_ck = progress.add_task("cookies", total=1, imported=0, skipped=0, failed=0)

    def render():
        for t in engine.snapshot():
            if t.task_id == "backup":
                progress.update(t_backup, total=max(t.total or 1, 1), completed=t.completed)
            elif t.task_id == "bookmarks":
                progress.update(t_bm, total=max(t.total or 1, 1), completed=t.completed,
                                imported=t.imported, skipped=t.skipped, failed=t.failed)
            elif t.task_id == "history":
                progress.update(t_hist, total=max(t.total or 1, 1), completed=t.completed,
                                imported=t.imported, skipped=t.skipped, failed=t.failed)
            elif t.task_id == "cookies":
                progress.update(t_ck, total=max(t.total or 1, 1), completed=t.completed,
                                imported=t.imported, skipped=t.skipped, failed=t.failed)
        return Group(progress, _items_panel(live_items))

    holder = {"report": {}}

    def loop():
        try:
            holder["report"] = run_migration(plan, src_a, dst_a, engine)
        except CancelledError:
            holder["report"] = {"status": "cancelled", "tasks": [], "backup": None}
        except BrowserShiftError as exc:
            holder["report"] = {"status": "failed", "tasks": [], "backup": None, "error": str(exc)}
        except Exception as exc:
            holder["report"] = {"status": "failed", "tasks": [], "backup": None, "error": str(exc)}

    with Live(render(), console=console, refresh_per_second=12, transient=False) as live:
        w = threading.Thread(target=loop, daemon=True)
        w.start()
        while w.is_alive():
            live.update(render())
            time.sleep(0.08)
        live.update(render())
        w.join()
    return holder["report"]


def _items_panel(items):
    if not items:
        body = Text("Waiting for the first item...", style=MUTED)
    else:
        body = Text()
        for line in items:
            if line.startswith("add"):
                style = SUCCESS
            elif line.startswith("skip"):
                style = WARNING
            elif line.startswith("error"):
                style = ERROR
            else:
                style = WHITE
            body.append(line + "\n", style=style)
    return Panel(body, title="[brand.light]Live items[/]", border_style=PURPLE, padding=(0, 1))


def _pick(browsers, role):
    console.print(section(f"{role} browser"))
    for i, b in enumerate(browsers, 1):
        console.print(f"  [brand.light]{i}.[/] {b.name} [muted]({len(b.profiles)} profiles)[/]")
    n = IntPrompt.ask(
        f"  Select {role.lower()} browser",
        choices=[str(i) for i in range(1, len(browsers) + 1)],
        default=1, show_choices=False,
    )
    b = browsers[n - 1]
    console.print()
    console.print(profile_table(b))
    if len(b.profiles) == 1:
        p = b.profiles[0]
        console.print(f"  [muted]Using profile:[/] [brand.light]{p.name}[/]")
    else:
        i = IntPrompt.ask(
            "  Select profile",
            choices=[str(i) for i in range(1, len(b.profiles) + 1)],
            default=1, show_choices=False,
        )
        p = b.profiles[i - 1]
    console.print()
    return b, p


def _pick_categories(available):
    for i, c in enumerate(available, 1):
        console.print(f"  [brand.light]{i}.[/] {c.value}")
    default = "1,2" if len(available) >= 2 else "1"
    if len(available) >= 3 and any(c.value == "cookies" for c in available):
        default = "1,2,3"
    raw = Prompt.ask("  Select categories (comma-separated)", default=default)
    chosen = []
    for tok in raw.split(","):
        tok = tok.strip()
        if not tok.isdigit():
            continue
        i = int(tok)
        if 1 <= i <= len(available):
            c = available[i - 1]
            if c not in chosen:
                chosen.append(c)
    console.print()
    return chosen


def _finale(report):
    t = Text()
    status = report.get("status", "unknown")
    headline = {
        "success": ("Migration complete.", SUCCESS),
        "partial": ("Migration completed with warnings.", WARNING),
        "failed": ("Migration failed.", ERROR),
        "cancelled": ("Migration cancelled.", WARNING),
    }.get(status, ("Migration finished.", PURPLE_LIGHT))
    t.append(headline[0] + "\n\n", style=f"bold {headline[1]}")

    b = report.get("backup") or {}
    if b:
        t.append("Backup saved at:\n", style=MUTED)
        t.append(f"  {b.get('path', '')}\n\n", style=WHITE)

    imported = sum(x.get("imported", 0) for x in report.get("tasks", []))
    skipped = sum(x.get("skipped", 0) for x in report.get("tasks", []))
    failed = sum(x.get("failed", 0) for x in report.get("tasks", []))

    t.append("Summary\n", style=f"bold {PURPLE_LIGHT}")
    t.append(f"  imported  {imported}\n", style=SUCCESS)
    t.append(f"  skipped   {skipped}\n", style=WARNING)
    t.append(f"  failed    {failed}\n\n", style=ERROR)

    if report.get("error"):
        t.append(f"Error: {report['error']}\n\n", style=ERROR)

    t.append(
        "You can delete me now - you won't need me anymore. AHAHAHA\n",
        style=f"bold {PURPLE_LIGHT}",
    )

    return Panel(t, title="[brand]BrowserShift[/]", border_style=PURPLE, padding=(1, 2))


def _clear():
    console.clear()


def _splash():
    t = Text()
    t.append("BrowserShift\n", style=f"bold {PURPLE}")
    t.append("Switch browsers. Keep your flow.\n", style=WHITE)
    t.append(f"v{__version__}\n", style=MUTED)
    stages = [
        "Initializing modules",
        "Loading platform paths",
        "Preparing browser registry",
        "Ready",
    ]
    with Live(Panel(Align.center(t), border_style=PURPLE, padding=(2, 4)),
              console=console, refresh_per_second=15, transient=True) as live:
        for s in stages:
            live.update(Panel(
                Group(Align.center(t), Align.center(Text(f"  {s}...", style=MUTED))),
                border_style=PURPLE, padding=(2, 4),
            ))
            time.sleep(0.3)