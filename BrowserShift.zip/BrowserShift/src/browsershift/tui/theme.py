from rich.theme import Theme
from rich.console import Console

PURPLE = "#A78BFA"
PURPLE_DEEP = "#7C3AED"
PURPLE_LIGHT = "#C4B5FD"
WHITE = "#F8FAFC"
MUTED = "#94A3B8"
SUCCESS = "#4ADE80"
WARNING = "#FBBF24"
ERROR = "#F87171"

THEME = Theme({
    "brand": f"bold {PURPLE}",
    "brand.light": PURPLE_LIGHT,
    "text": WHITE,
    "muted": MUTED,
    "success": f"bold {SUCCESS}",
    "warning": f"bold {WARNING}",
    "error": f"bold {ERROR}",
    "label": f"bold {PURPLE_LIGHT}",
    "value": f"bold {WHITE}",
    "rule": PURPLE,
    "panel.border": PURPLE,
})


def make_console():
    return Console(theme=THEME, highlight=False, soft_wrap=False)


LOGO = r"""
                                                                  
    ▄▄▄                                         ▄▄▄▄▄             ▄▄    
   ██▀▀█▄                                      ██▀▀▀▀█▄ █▄       ██  █▄ 
   ██ ▄█▀ ▄                               ▄    ▀██▄  ▄▀ ██    ▀▀▄██▄▄██▄
   ██▀▀█▄ ████▄▄███▄▀█▄ █▄ ██▀▄██▀█ ▄█▀█▄ ████▄  ▀██▄▄  ████▄ ██ ██  ██ 
 ▄ ██  ▄█ ██   ██ ██ ██▄██▄██ ▀███▄ ██▄█▀ ██   ▄   ▀██▄ ██ ██ ██ ██  ██ 
 ▀██████▀▄█▀  ▄▀███▀  ▀██▀██▀█▄▄██▀▄▀█▄▄▄▄█▀   ▀██████▀▄██ ██▄██▄██ ▄██ 
                                                                 ██     
                                                                ▀▀      
"""