import base64
import json
import os
import shutil
import sqlite3
import tempfile
from pathlib import Path

from ..utils.platform import is_windows, is_linux

try:
    import win32crypt
except Exception:
    win32crypt = None

try:
    from Crypto.Cipher import AES
    from Crypto.Protocol.KDF import PBKDF2
    from Crypto.Hash import SHA1
except Exception:
    AES = None
    PBKDF2 = None
    SHA1 = None


LINUX_PASSWORD = b"peanuts"
LINUX_SALT = b"saltysalt"
LINUX_IV = b" " * 16
LINUX_ITERATIONS = 1


def _local_state(profile):
    return profile.path.parent / "Local State"


def _master_key(profile):
    ls = _local_state(profile)
    if not ls.is_file():
        return None
    try:
        data = json.loads(ls.read_text(encoding="utf-8", errors="ignore"))
    except Exception:
        return None
    enc = data.get("os_crypt", {}).get("encrypted_key")
    if not enc:
        return None
    try:
        raw = base64.b64decode(enc)
    except Exception:
        return None

    if is_windows():
        if win32crypt is None or raw[:5] != b"DPAPI":
            return None
        try:
            return win32crypt.CryptUnprotectData(raw[5:], None, None, None, 0)[1]
        except Exception:
            return None

    if is_linux():
        if PBKDF2 is None or AES is None:
            return None
        try:
            k = PBKDF2(
                LINUX_PASSWORD, LINUX_SALT, 16,
                count=LINUX_ITERATIONS, hmac_hash_module=SHA1,
            )
            c = AES.new(k, AES.MODE_CBC, LINUX_IV)
            decrypted = c.decrypt(raw)
            return decrypted[-16:]
        except Exception:
            return None

    return None


def _prefix():
    if is_windows():
        return b"v10"
    if is_linux():
        return b"v11"
    return b"v10"


def _decrypt(blob, key):
    if not blob:
        return ""
    if blob[:3] in (b"v10", b"v11") and key and AES:
        nonce = blob[3:15]
        ct = blob[15:-16]
        tag = blob[-16:]
        try:
            c = AES.new(key, AES.MODE_GCM, nonce=nonce)
            return c.decrypt_and_verify(ct, tag).decode("utf-8", "replace")
        except Exception:
            return ""
    if is_windows() and win32crypt:
        try:
            return win32crypt.CryptUnprotectData(
                blob, None, None, None, 0
            )[1].decode("utf-8", "replace")
        except Exception:
            return ""
    return ""


def _encrypt(value, key):
    if not key or not AES:
        return None
    nonce = os.urandom(12)
    c = AES.new(key, AES.MODE_GCM, nonce=nonce)
    ct, tag = c.encrypt_and_digest(value.encode("utf-8"))
    return _prefix() + nonce + ct + tag


def read_cookies(profile, on_item=None):
    db = profile.path / "Cookies"
    if not db.is_file():
        return []
    key = _master_key(profile)
    tmp = Path(tempfile.mkstemp(prefix="bshift_ck_", suffix=".db")[1])
    shutil.copy2(db, tmp)
    try:
        conn = sqlite3.connect(str(tmp))
        conn.row_factory = sqlite3.Row
        try:
            rows = conn.execute("SELECT * FROM cookies").fetchall()
        except sqlite3.Error:
            rows = []
        finally:
            conn.close()
    finally:
        tmp.unlink(missing_ok=True)

    out = []
    for row in rows:
        row = dict(row)
        plain = row.get("value") or ""
        if not plain:
            enc = row.get("encrypted_value") or b""
            if isinstance(enc, str):
                enc = enc.encode("latin-1", "ignore")
            plain = _decrypt(enc, key)
        item = {
            "host_key": row.get("host_key", "") or "",
            "name": row.get("name", "") or "",
            "value": plain,
            "path": row.get("path", "/") or "/",
            "expires_utc": row.get("expires_utc", 0) or 0,
            "is_secure": row.get("is_secure", 0) or 0,
            "is_httponly": row.get("is_httponly", 0) or 0,
            "samesite": row.get("samesite", 0) or 0,
        }
        out.append(item)
        if on_item:
            on_item(item)
    return out


def write_cookies(profile, items, on_item=None):
    db = profile.path / "Cookies"
    if not db.is_file():
        return 0, 0, 0
    key = _master_key(profile)
    if not key or not AES:
        if on_item:
            for it in items:
                on_item(it, "error")
        return 0, 0, len(items)

    conn = sqlite3.connect(str(db))
    try:
        cols = [r[1] for r in conn.execute("PRAGMA table_info(cookies)").fetchall()]
        existing = set()
        try:
            for r in conn.execute("SELECT host_key, name, path FROM cookies"):
                existing.add((r[0], r[1], r[2]))
        except sqlite3.Error:
            pass

        imported = skipped = failed = 0
        for item in items:
            k3 = (item["host_key"], item["name"], item["path"])
            if k3 in existing:
                skipped += 1
                if on_item:
                    on_item(item, "skip")
                continue
            enc = _encrypt(item["value"], key)
            if enc is None:
                failed += 1
                if on_item:
                    on_item(item, "error")
                continue
            payload = {
                "host_key": item["host_key"],
                "name": item["name"],
                "value": "",
                "encrypted_value": enc,
                "path": item["path"],
                "expires_utc": int(item.get("expires_utc") or 0),
                "is_secure": int(item.get("is_secure") or 0),
                "is_httponly": int(item.get("is_httponly") or 0),
                "samesite": int(item.get("samesite") or 0),
            }
            use = {k: v for k, v in payload.items() if k in cols}
            try:
                q = (
                    "INSERT INTO cookies ("
                    + ",".join(use.keys())
                    + ") VALUES ("
                    + ",".join("?" * len(use))
                    + ")"
                )
                conn.execute(q, list(use.values()))
                existing.add(k3)
                imported += 1
                if on_item:
                    on_item(item, "add")
            except sqlite3.Error:
                failed += 1
                if on_item:
                    on_item(item, "error")
        conn.commit()
    finally:
        conn.close()
    return imported, skipped, failed