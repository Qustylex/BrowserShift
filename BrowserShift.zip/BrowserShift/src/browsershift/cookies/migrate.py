from ..utils.exceptions import UnsupportedOperationError


FIREFOX_TO_CHROMIUM_OFFSET = 11644473600


def migrate(source_adapter, source_profile, dest_adapter, dest_profile, progress):
    if source_adapter.family == "chromium":
        from . import chromium as src
    elif source_adapter.family == "firefox":
        from . import firefox as src
    else:
        raise UnsupportedOperationError("Unsupported source for cookies: " + source_adapter.family)

    if dest_adapter.family != "chromium":
        raise UnsupportedOperationError(
            "Cookie writing is only supported into Chromium destinations in this release."
        )

    from . import chromium as dst

    progress.emit("Reading cookies from source...")
    items = src.read_cookies(source_profile)
    progress.set_total(len(items))
    progress.emit(f"Read {len(items)} cookies")

    if source_adapter.family == "firefox":
        for it in items:
            exp = int(it.get("expires_utc") or 0)
            if exp > 0:
                it["expires_utc"] = (exp + FIREFOX_TO_CHROMIUM_OFFSET) * 1_000_000

    def on_item(item, status):
        label = (item["host_key"] + item["name"])[:70]
        if status == "add":
            progress.tick_imported()
            progress.emit(f"add   cookie {label}")
        elif status == "skip":
            progress.tick_skipped()
            progress.emit(f"skip  cookie {label}")
        else:
            progress.tick_failed()
            progress.emit(f"error cookie {label}")

    imported, skipped, failed = dst.write_cookies(dest_profile, items, on_item)
    return {
        "category": "cookies",
        "status": "done" if failed == 0 else "failed",
        "imported": imported,
        "skipped": skipped,
        "failed": failed,
    }