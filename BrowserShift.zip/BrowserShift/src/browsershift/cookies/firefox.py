import shutil
import sqlite3
import tempfile
from pathlib import Path


def read_cookies(profile, on_item=None):
    db = profile.path / "cookies.sqlite"
    if not db.is_file():
        return []
    tmp = Path(tempfile.mkstemp(prefix="bshift_ff_", suffix=".db")[1])
    shutil.copy2(db, tmp)
    try:
        conn = sqlite3.connect(str(tmp))
        conn.row_factory = sqlite3.Row
        try:
            rows = conn.execute("SELECT * FROM moz_cookies").fetchall()
        except sqlite3.Error:
            rows = []
        finally:
            conn.close()
    finally:
        tmp.unlink(missing_ok=True)

    out = []
    for row in rows:
        row = dict(row)
        item = {
            "host_key": row.get("host", "") or "",
            "name": row.get("name", "") or "",
            "value": row.get("value", "") or "",
            "path": row.get("path", "/") or "/",
            "expires_utc": row.get("expiry", 0) or 0,
            "is_secure": row.get("isSecure", 0) or 0,
            "is_httponly": row.get("isHttpOnly", 0) or 0,
            "samesite": 0,
        }
        out.append(item)
        if on_item:
            on_item(item)
    return out