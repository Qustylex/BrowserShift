from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path


class Capability(Enum):
    SUPPORTED = "supported"
    PARTIAL = "partial"
    UNSUPPORTED = "unsupported"
    NOT_TESTED = "not_tested"


class Category(Enum):
    BOOKMARKS = "bookmarks"
    HISTORY = "history"
    COOKIES = "cookies"
    OPEN_TABS = "open_tabs"
    EXTENSIONS = "extensions"
    SETTINGS = "settings"


@dataclass(frozen=True)
class BookmarkItem:
    title: str
    url: str
    folder: tuple[str, ...] = ()
    added_at: datetime | None = None


@dataclass(frozen=True)
class HistoryItem:
    url: str
    title: str
    last_visit: datetime
    visit_count: int = 1


@dataclass
class BrowserProfile:
    id: str
    name: str
    path: Path
    is_default: bool = False


@dataclass
class DetectedBrowser:
    id: str
    name: str
    family: str
    profile_root: Path
    profiles: list[BrowserProfile] = field(default_factory=list)


class BrowserAdapter(ABC):
    id: str = ""
    name: str = ""
    family: str = ""

    def capabilities(self) -> dict[Category, Capability]:
        return {c: Capability.NOT_TESTED for c in Category}

    @abstractmethod
    def detect(self) -> DetectedBrowser | None:
        ...

    @abstractmethod
    def read_bookmarks(self, profile: BrowserProfile) -> list[BookmarkItem]:
        ...

    @abstractmethod
    def read_history(self, profile: BrowserProfile) -> list[HistoryItem]:
        ...