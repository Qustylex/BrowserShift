import json
import os
import shutil
import sqlite3
import tempfile
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path

from .base import (
    BrowserAdapter, BrowserProfile, DetectedBrowser,
    BookmarkItem, HistoryItem, Capability, Category,
)
from .profiles import enumerate_chromium_profiles
from ..utils.platform import (
    CURRENT_OS, OS, config_root,
    windows_local_appdata, windows_roaming_appdata,
    macos_app_support, linux_config_home, home,
)


CHROMIUM_EPOCH = datetime(1601, 1, 1, tzinfo=timezone.utc)


def chromium_time_to_datetime(micros: int) -> datetime:
    return CHROMIUM_EPOCH + timedelta(microseconds=int(micros))


def datetime_to_chromium_time(dt: datetime) -> int:
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return int((dt - CHROMIUM_EPOCH).total_seconds() * 1_000_000)


@dataclass(frozen=True)
class ChromiumTarget:
    id: str
    name: str
    windows_local: str = ""
    windows_roaming: str = ""
    macos_support: str = ""
    linux_config: str = ""

    def resolve_root(self):
        cands = []
        if CURRENT_OS is OS.WINDOWS:
            if self.windows_local:
                cands.append(windows_local_appdata() / self.windows_local)
            if self.windows_roaming:
                cands.append(windows_roaming_appdata() / self.windows_roaming)
        elif CURRENT_OS is OS.MACOS:
            if self.macos_support:
                cands.append(macos_app_support() / self.macos_support)
        elif CURRENT_OS is OS.LINUX:
            if self.linux_config:
                cands.append(linux_config_home() / self.linux_config)
            if self.windows_local:
                cands.append(home() / ".config" / self.windows_local)
        else:
            if self.linux_config:
                cands.append(config_root() / self.linux_config)
        for c in cands:
            if c.is_dir():
                return c
        return None


CHROMIUM_TARGETS = [
    ChromiumTarget("chrome", "Google Chrome",
                   "Google/Chrome/User Data", "", "Google/Chrome", "google-chrome"),
    ChromiumTarget("edge", "Microsoft Edge",
                   "Microsoft/Edge/User Data", "", "Microsoft Edge", "microsoft-edge"),
    ChromiumTarget("brave", "Brave",
                   "BraveSoftware/Brave-Browser/User Data", "",
                   "BraveSoftware/Brave-Browser", "BraveSoftware/Brave-Browser"),
    ChromiumTarget("vivaldi", "Vivaldi",
                   "Vivaldi/User Data", "", "Vivaldi", "vivaldi"),
    ChromiumTarget("opera", "Opera",
                   "", "Opera Software/Opera Stable",
                   "com.operasoftware.Opera", "opera"),
    ChromiumTarget("opera_gx", "Opera GX",
                   "", "Opera Software/Opera GX Stable",
                   "com.operasoftware.OperaGX", "opera-gx"),
]


class ChromiumAdapter(BrowserAdapter):
    family = "chromium"

    def __init__(self, target: ChromiumTarget):
        self.target = target
        self.id = target.id
        self.name = target.name

    def capabilities(self):
        return {
            Category.BOOKMARKS: Capability.SUPPORTED,
            Category.HISTORY: Capability.SUPPORTED,
            Category.COOKIES: Capability.SUPPORTED,
            Category.OPEN_TABS: Capability.PARTIAL,
            Category.EXTENSIONS: Capability.PARTIAL,
            Category.SETTINGS: Capability.PARTIAL,
        }

    def detect(self):
        root = self.target.resolve_root()
        if root is None:
            return None
        profiles = enumerate_chromium_profiles(root)
        if not profiles:
            return None
        return DetectedBrowser(
            id=self.id, name=self.name, family=self.family,
            profile_root=root, profiles=profiles,
        )

    def read_bookmarks(self, profile):
        f = profile.path / "Bookmarks"
        if not f.is_file():
            return []
        try:
            data = json.loads(f.read_text(encoding="utf-8", errors="ignore"))
        except Exception:
            return []
        out = []
        roots = data.get("roots", {})
        for key in ("bookmark_bar", "other", "synced"):
            node = roots.get(key)
            if node:
                self._walk(node, (), out)
        return out

    def _walk(self, node, folder, out):
        t = node.get("type")
        name = (node.get("name") or "").strip()
        if t == "url":
            url = node.get("url") or ""
            if url:
                out.append(BookmarkItem(title=name or url, url=url, folder=folder))
            return
        if t == "folder":
            nf = folder + ((name,) if name else ())
            for c in node.get("children") or []:
                self._walk(c, nf, out)

    def read_history(self, profile):
        f = profile.path / "History"
        if not f.is_file():
            return []
        tmp = _copy_temp(f)
        try:
            conn = sqlite3.connect(f"file:{_uri(tmp)}?mode=ro", uri=True)
            try:
                rows = conn.execute(
                    "SELECT url, title, visit_count, last_visit_time FROM urls "
                    "WHERE last_visit_time > 0 ORDER BY last_visit_time DESC"
                ).fetchall()
            finally:
                conn.close()
        finally:
            tmp.unlink(missing_ok=True)
        out = []
        for url, title, count, last in rows:
            if not url:
                continue
            try:
                when = chromium_time_to_datetime(int(last))
            except Exception:
                continue
            out.append(HistoryItem(
                url=url, title=title or url, last_visit=when,
                visit_count=max(int(count or 1), 1),
            ))
        return out


def _copy_temp(source: Path) -> Path:
    fd, name = tempfile.mkstemp(prefix="bshift_", suffix=source.suffix)
    os.close(fd)
    tmp = Path(name)
    shutil.copy2(source, tmp)
    return tmp


def _uri(path: Path) -> str:
    return path.as_posix() if os.name == "nt" else str(path)