from .base import BrowserAdapter, DetectedBrowser
from .chromium import ChromiumAdapter, CHROMIUM_TARGETS
from .firefox import FirefoxAdapter


def build_adapters() -> list[BrowserAdapter]:
    adapters = [ChromiumAdapter(t) for t in CHROMIUM_TARGETS]
    adapters.append(FirefoxAdapter())
    return adapters


def detect_all() -> list[DetectedBrowser]:
    out = []
    for a in build_adapters():
        b = a.detect()
        if b and b.profiles:
            out.append(b)
    return out


def find_browser(browser_id: str):
    for a in build_adapters():
        if a.id == browser_id:
            return a.detect()
    return None