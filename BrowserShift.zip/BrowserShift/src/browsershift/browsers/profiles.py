import configparser
import json
from pathlib import Path
from .base import BrowserProfile


CHROMIUM_SKIP = {"Guest Profile", "System Profile", "Snapshot", "Crashpad", "ShaderCache"}


def enumerate_chromium_profiles(root: Path) -> list[BrowserProfile]:
    if not root.is_dir():
        return []
    profiles: list[BrowserProfile] = []
    for entry in sorted(root.iterdir()):
        if not entry.is_dir() or entry.name in CHROMIUM_SKIP:
            continue
        prefs = entry / "Preferences"
        bm = entry / "Bookmarks"
        hist = entry / "History"
        ck = entry / "Cookies"
        if not (prefs.is_file() or bm.is_file() or hist.is_file() or ck.is_file()):
            continue
        profiles.append(BrowserProfile(
            id=entry.name,
            name=_chromium_name(prefs) or entry.name,
            path=entry,
            is_default=entry.name == "Default",
        ))
    if profiles and not any(p.is_default for p in profiles):
        profiles[0].is_default = True
    return profiles


def _chromium_name(prefs: Path) -> str | None:
    if not prefs.is_file():
        return None
    try:
        data = json.loads(prefs.read_text(encoding="utf-8", errors="ignore"))
    except Exception:
        return None
    n = data.get("profile", {}).get("name")
    return n.strip() if isinstance(n, str) and n.strip() else None


def enumerate_firefox_profiles(root: Path) -> list[BrowserProfile]:
    ini = root / "profiles.ini"
    if not ini.is_file():
        return []
    parser = configparser.ConfigParser()
    try:
        parser.read(ini, encoding="utf-8")
    except Exception:
        return []
    profiles: list[BrowserProfile] = []
    default_id = parser.defaults().get("Default")
    for section in parser.sections():
        if not section.startswith("Profile"):
            continue
        pv = parser.get(section, "Path", fallback="").strip()
        if not pv:
            continue
        rel = parser.getboolean(section, "IsRelative", fallback=True)
        p = (root / pv) if rel else Path(pv)
        p = p.resolve()
        if not p.is_dir():
            continue
        pid = p.name
        name = parser.get(section, "Name", fallback=pid) or pid
        profiles.append(BrowserProfile(
            id=pid, name=name, path=p,
            is_default=bool(default_id and pid == default_id),
        ))
    if profiles and not any(x.is_default for x in profiles):
        profiles[0].is_default = True
    return profiles