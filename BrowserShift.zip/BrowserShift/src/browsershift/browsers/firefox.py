import os
import shutil
import sqlite3
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

from .base import (
    BrowserAdapter, BrowserProfile, DetectedBrowser,
    BookmarkItem, HistoryItem, Capability, Category,
)
from .profiles import enumerate_firefox_profiles
from ..utils.platform import (
    CURRENT_OS, OS,
    windows_roaming_appdata, macos_app_support,
    linux_config_home, home,
)


FIREFOX_EPOCH = datetime(1970, 1, 1, tzinfo=timezone.utc)


def firefox_time_to_datetime(micros) -> datetime:
    if not micros:
        return datetime.now(timezone.utc)
    return FIREFOX_EPOCH + timedelta(microseconds=int(micros))


def _firefox_root():
    cands = []
    if CURRENT_OS is OS.WINDOWS:
        cands.append(windows_roaming_appdata() / "Mozilla" / "Firefox")
    elif CURRENT_OS is OS.MACOS:
        cands.append(macos_app_support() / "Firefox")
    elif CURRENT_OS is OS.LINUX:
        cands.append(home() / ".mozilla" / "firefox")
        cands.append(linux_config_home() / "mozilla" / "firefox")
    else:
        cands.append(home() / ".mozilla" / "firefox")
    for c in cands:
        if c.is_dir():
            return c
    return None


class FirefoxAdapter(BrowserAdapter):
    id = "firefox"
    name = "Mozilla Firefox"
    family = "firefox"

    def capabilities(self):
        return {
            Category.BOOKMARKS: Capability.PARTIAL,
            Category.HISTORY: Capability.PARTIAL,
            Category.COOKIES: Capability.PARTIAL,
            Category.OPEN_TABS: Capability.PARTIAL,
            Category.EXTENSIONS: Capability.PARTIAL,
            Category.SETTINGS: Capability.PARTIAL,
        }

    def detect(self):
        root = _firefox_root()
        if root is None:
            return None
        profiles = enumerate_firefox_profiles(root)
        if not profiles:
            return None
        return DetectedBrowser(
            id=self.id, name=self.name, family=self.family,
            profile_root=root, profiles=profiles,
        )

    def _places(self, profile):
        return profile.path / "places.sqlite"

    def read_bookmarks(self, profile):
        places = self._places(profile)
        if not places.is_file():
            return []
        tmp = _copy_temp(places)
        try:
            conn = sqlite3.connect(f"file:{_uri(tmp)}?mode=ro", uri=True)
            conn.row_factory = sqlite3.Row
            try:
                roots = conn.execute(
                    "SELECT id, parent, title, type, fk FROM moz_bookmarks "
                    "WHERE parent IN (SELECT id FROM moz_bookmarks WHERE parent = 0)"
                ).fetchall()
                out = []
                for root in roots:
                    self._walk(conn, root["id"], (self._label(root),), out)
                return out
            finally:
                conn.close()
        finally:
            tmp.unlink(missing_ok=True)

    def _label(self, row):
        t = (row["title"] or "").strip()
        return t or "Bookmarks"

    def _walk(self, conn, parent_id, folder, out):
        rows = conn.execute(
            "SELECT b.id, b.title, b.type, b.fk, p.url "
            "FROM moz_bookmarks b LEFT JOIN moz_places p ON p.id = b.fk "
            "WHERE b.parent = ? ORDER BY b.position",
            (parent_id,),
        ).fetchall()
        for row in rows:
            t = (row["title"] or "").strip()
            if row["type"] == 1 and row["url"]:
                out.append(BookmarkItem(title=t or row["url"], url=row["url"], folder=folder))
            elif row["type"] == 2:
                nf = folder + ((t,) if t else ())
                self._walk(conn, row["id"], nf, out)

    def read_history(self, profile):
        places = self._places(profile)
        if not places.is_file():
            return []
        tmp = _copy_temp(places)
        try:
            conn = sqlite3.connect(f"file:{_uri(tmp)}?mode=ro", uri=True)
            try:
                rows = conn.execute(
                    "SELECT url, title, visit_count, last_visit_date FROM moz_places "
                    "WHERE last_visit_date IS NOT NULL AND hidden = 0 "
                    "ORDER BY last_visit_date DESC"
                ).fetchall()
            finally:
                conn.close()
        finally:
            tmp.unlink(missing_ok=True)
        out = []
        for url, title, count, last in rows:
            if not url:
                continue
            out.append(HistoryItem(
                url=url, title=title or url,
                last_visit=firefox_time_to_datetime(last),
                visit_count=max(int(count or 1), 1),
            ))
        return out


def _copy_temp(source: Path) -> Path:
    fd, name = tempfile.mkstemp(prefix="bshift_", suffix=source.suffix)
    os.close(fd)
    tmp = Path(name)
    shutil.copy2(source, tmp)
    return tmp


def _uri(path: Path) -> str:
    return path.as_posix() if os.name == "nt" else str(path)