from datetime import datetime

from ..browsers.base import Category
from ..backup.create import create_backup
from ..backup.verify import verify_backup
from ..migration import bookmarks as bm
from ..migration import history as hist
from ..cookies import migrate as ck
from ..utils.exceptions import CancelledError
from .progress import Status


WEIGHTS = {
    Category.BOOKMARKS: 3.0,
    Category.HISTORY: 4.0,
    Category.COOKIES: 3.0,
}


def run_migration(plan, source_adapter, dest_adapter, engine):
    result = {
        "started_at": datetime.now().isoformat(timespec="seconds"),
        "plan": plan.label(),
        "categories": [c.value for c in plan.categories],
        "backup": None,
        "tasks": [],
        "status": "unknown",
    }

    if plan.backup_required:
        engine.register("backup", "backup", weight=2.0)
        engine.update("backup", status=Status.RUNNING, operation="Creating backup")
        try:
            b = create_backup(
                destination_profile=plan.destination_profile,
                browser_id=plan.destination_browser_id,
                on_progress=lambda done, total: engine.update(
                    "backup", completed=done, total=total
                ),
            )
            engine.update("backup", status=Status.DONE, operation="Backup done")
            result["backup"] = {"id": b.identifier, "path": str(b.path)}
            v = verify_backup(b.path)
            if not v.ok:
                engine.update("backup", status=Status.FAILED, message=v.message)
                result["status"] = "failed"
                return result
        except Exception as exc:
            engine.update("backup", status=Status.FAILED, message=str(exc))
            result["status"] = "failed"
            return result

    for cat in plan.categories:
        if engine.is_cancelled:
            raise CancelledError("Cancelled by user")
        weight = WEIGHTS.get(cat, 1.0)
        tid = cat.value
        engine.register(tid, cat.value, weight=weight)
        engine.update(tid, status=Status.RUNNING, operation=f"Migrating {tid}")
        handle = engine.handle(tid)

        try:
            if cat is Category.BOOKMARKS:
                tr = bm.migrate(source_adapter, plan.source_profile,
                                dest_adapter, plan.destination_profile, handle)
            elif cat is Category.HISTORY:
                tr = hist.migrate(source_adapter, plan.source_profile,
                                  dest_adapter, plan.destination_profile, handle)
            elif cat is Category.COOKIES:
                tr = ck.migrate(source_adapter, plan.source_profile,
                                dest_adapter, plan.destination_profile, handle)
            else:
                engine.update(tid, status=Status.SKIPPED,
                              operation="Not supported in this release")
                result["tasks"].append({"category": cat.value, "status": "skipped"})
                continue
        except CancelledError:
            engine.update(tid, status=Status.CANCELLED)
            raise
        except Exception as exc:
            engine.update(tid, status=Status.FAILED, message=str(exc))
            result["tasks"].append(
                {"category": cat.value, "status": "failed", "error": str(exc)}
            )
            continue

        engine.update(
            tid,
            status=Status.DONE if tr.get("failed", 0) == 0 else Status.FAILED,
        )
        result["tasks"].append(tr)

    result["finished_at"] = datetime.now().isoformat(timespec="seconds")
    if engine.is_cancelled:
        result["status"] = "cancelled"
    elif any(t.get("status") == "failed" for t in result["tasks"]):
        result["status"] = "partial"
    else:
        result["status"] = "success"
    return result