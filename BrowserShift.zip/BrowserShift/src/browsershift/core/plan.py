from dataclasses import dataclass, field
from ..browsers.base import BrowserProfile, Category


@dataclass
class MigrationPlan:
    source_browser_id: str
    source_browser_name: str
    source_profile: BrowserProfile
    destination_browser_id: str
    destination_browser_name: str
    destination_profile: BrowserProfile
    categories: list = field(default_factory=list)
    backup_required: bool = True

    def label(self):
        return f"{self.source_browser_name} ({self.source_profile.name}) -> {self.destination_browser_name} ({self.destination_profile.name})"