from dataclasses import dataclass
from enum import Enum
from threading import Lock


class Status(Enum):
    PENDING = "pending"
    RUNNING = "running"
    DONE = "done"
    SKIPPED = "skipped"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class TaskProgress:
    task_id: str
    category: str
    operation: str = ""
    weight: float = 1.0
    completed: int = 0
    total: int | None = None
    status: Status = Status.PENDING
    imported: int = 0
    skipped: int = 0
    failed: int = 0
    message: str = ""


class ProgressHandle:
    def __init__(self, engine, task_id):
        self._engine = engine
        self._task_id = task_id

    @property
    def is_cancelled(self):
        return self._engine.is_cancelled

    def set_total(self, total):
        self._engine.set_total(self._task_id, total)

    def emit(self, message):
        self._engine.emit(self._task_id, message)

    def tick_imported(self):
        self._engine.add_imported(self._task_id)

    def tick_skipped(self):
        self._engine.add_skipped(self._task_id)

    def tick_failed(self):
        self._engine.add_failed(self._task_id)


class ProgressEngine:
    def __init__(self, on_event=None):
        self._tasks = {}
        self._order = []
        self._lock = Lock()
        self._cancelled = False
        self._on_event = on_event

    def register(self, task_id, category, weight=1.0):
        with self._lock:
            t = TaskProgress(task_id=task_id, category=category, weight=max(weight, 0.0))
            self._tasks[task_id] = t
            self._order.append(task_id)
            return t

    def handle(self, task_id):
        return ProgressHandle(self, task_id)

    def cancel(self):
        with self._lock:
            self._cancelled = True

    @property
    def is_cancelled(self):
        return self._cancelled

    def update(self, task_id, **fields):
        with self._lock:
            t = self._tasks.get(task_id)
            if not t:
                return
            for k, v in fields.items():
                if hasattr(t, k):
                    setattr(t, k, v)
        self._fire(task_id)

    def set_total(self, task_id, total):
        with self._lock:
            t = self._tasks.get(task_id)
            if not t:
                return
            t.total = total
        self._fire(task_id)

    def add_imported(self, task_id, n=1):
        with self._lock:
            t = self._tasks.get(task_id)
            if not t:
                return
            t.imported += n
            t.completed += n
        self._fire(task_id)

    def add_skipped(self, task_id, n=1):
        with self._lock:
            t = self._tasks.get(task_id)
            if not t:
                return
            t.skipped += n
            t.completed += n
        self._fire(task_id)

    def add_failed(self, task_id, n=1):
        with self._lock:
            t = self._tasks.get(task_id)
            if not t:
                return
            t.failed += n
            t.completed += n
        self._fire(task_id)

    def emit(self, task_id, message):
        if self._on_event:
            self._on_event({"kind": "item", "task_id": task_id, "message": message})

    def overall_percent(self):
        with self._lock:
            tw = sum(t.weight for t in self._tasks.values()) or 1.0
            dw = 0.0
            for t in self._tasks.values():
                if t.status in (Status.DONE, Status.FAILED, Status.SKIPPED, Status.CANCELLED):
                    dw += t.weight
                elif t.total and t.total > 0:
                    dw += t.weight * min(t.completed / t.total, 1.0)
            return min(dw / tw * 100.0, 100.0)

    def snapshot(self):
        with self._lock:
            return [self._tasks[tid] for tid in self._order]

    def _fire(self, task_id):
        if not self._on_event:
            return
        with self._lock:
            t = self._tasks.get(task_id)
            if not t:
                return
            p = {
                "kind": "task", "task_id": task_id, "category": t.category,
                "operation": t.operation, "completed": t.completed, "total": t.total,
                "status": t.status.value, "imported": t.imported, "skipped": t.skipped,
                "failed": t.failed, "percent": self.overall_percent(),
            }
        self._on_event(p)