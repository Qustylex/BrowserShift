import json
import os
import tempfile
import uuid
from pathlib import Path

from ..utils.exceptions import MigrationError, UnsupportedOperationError


def migrate(source, source_profile, destination, dest_profile, progress):
    items = source.read_bookmarks(source_profile)
    progress.set_total(len(items))
    progress.emit(f"Read {len(items)} bookmarks from {source.name}")

    if destination.family == "chromium":
        imported, skipped, failed = _write_chromium(dest_profile, items, progress)
    elif destination.family == "firefox":
        raise UnsupportedOperationError(
            "Writing bookmarks into Firefox is not supported in this release."
        )
    else:
        raise UnsupportedOperationError(f"Unsupported destination: {destination.family}")

    return {
        "category": "bookmarks",
        "status": "done" if failed == 0 else "failed",
        "imported": imported, "skipped": skipped, "failed": failed,
    }


def _write_chromium(profile, items, progress):
    f = profile.path / "Bookmarks"
    if not f.is_file():
        raise MigrationError(f"Bookmarks file missing in {profile.path}")
    data = json.loads(f.read_text(encoding="utf-8"))
    existing = _urls(data)
    bar = data.setdefault("roots", {}).setdefault("bookmark_bar", _folder("Bookmarks bar"))
    imported = skipped = failed = 0
    cache = {(): bar}

    for item in items:
        if progress.is_cancelled:
            break
        if item.url in existing:
            skipped += 1
            progress.tick_skipped()
            progress.emit(f"skip  {_trim(item.title)}")
            continue
        try:
            parent = _ensure(bar, item.folder, cache)
            children = parent.setdefault("children", [])
            children.append({
                "date_added": "0",
                "guid": str(uuid.uuid4()),
                "id": str(_next_id(data)),
                "name": item.title,
                "type": "url",
                "url": item.url,
            })
            existing.add(item.url)
            imported += 1
            progress.tick_imported()
            progress.emit(f"add   {_trim(item.title)}  ->  {_trim(item.url, 50)}")
        except Exception as exc:
            failed += 1
            progress.tick_failed()
            progress.emit(f"error {_trim(str(exc))}")

    _atomic_json(f, data)
    return imported, skipped, failed


def _trim(v, w=70):
    v = (v or "").replace("\n", " ").strip()
    return v if len(v) <= w else v[: w - 1] + "..."


def _folder(name):
    return {
        "children": [], "date_added": "0", "date_last_used": "0",
        "date_modified": "0", "guid": str(uuid.uuid4()), "id": "0",
        "name": name, "type": "folder",
    }


def _next_id(data):
    m = 0
    def walk(n):
        nonlocal m
        try:
            m = max(m, int(n.get("id", 0)))
        except Exception:
            pass
        for c in n.get("children") or []:
            walk(c)
    for k in ("bookmark_bar", "other", "synced"):
        r = data.get("roots", {}).get(k)
        if r:
            walk(r)
    return m + 1


def _urls(data):
    s = set()
    def walk(n):
        if n.get("type") == "url" and n.get("url"):
            s.add(n["url"])
        for c in n.get("children") or []:
            walk(c)
    for k in ("bookmark_bar", "other", "synced"):
        r = data.get("roots", {}).get(k)
        if r:
            walk(r)
    return s


def _ensure(root, path, cache):
    node = root
    key = ()
    for part in path:
        key = key + (part,)
        if key in cache:
            node = cache[key]
            continue
        children = node.setdefault("children", [])
        found = next(
            (c for c in children if c.get("type") == "folder" and (c.get("name") or "").strip() == part),
            None,
        )
        if not found:
            found = _folder(part)
            children.append(found)
        cache[key] = found
        node = found
    return node


def _atomic_json(path, data):
    fd, name = tempfile.mkstemp(prefix="bshift_bm_", suffix=".json", dir=str(path.parent))
    os.close(fd)
    tmp = Path(name)
    try:
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=3), encoding="utf-8")
        os.replace(tmp, path)
    finally:
        if tmp.exists():
            tmp.unlink(missing_ok=True)