import os
import sqlite3
from pathlib import Path

from ..browsers.chromium import datetime_to_chromium_time
from ..utils.exceptions import MigrationError, ProfileLockedError, UnsupportedOperationError


def migrate(source, source_profile, destination, dest_profile, progress):
    items = source.read_history(source_profile)
    progress.set_total(len(items))
    progress.emit(f"Read {len(items)} history entries from {source.name}")

    if destination.family == "chromium":
        imported, skipped, failed = _write_chromium(dest_profile, items, progress)
    elif destination.family == "firefox":
        raise UnsupportedOperationError(
            "Writing history into Firefox is not supported in this release."
        )
    else:
        raise UnsupportedOperationError(f"Unsupported destination: {destination.family}")

    return {
        "category": "history",
        "status": "done" if failed == 0 else "failed",
        "imported": imported, "skipped": skipped, "failed": failed,
    }


def _write_chromium(profile, items, progress):
    f = profile.path / "History"
    if not f.is_file():
        raise MigrationError(f"History file missing in {profile.path}")
    if _is_locked(f):
        raise ProfileLockedError(
            f"Profile '{profile.name}' is in use. Close the destination browser and retry."
        )
    conn = sqlite3.connect(str(f))
    try:
        conn.execute("PRAGMA journal_mode=WAL")
        existing = {r[0] for r in conn.execute("SELECT url FROM urls")}
        imported = skipped = failed = 0
        for item in items:
            if progress.is_cancelled:
                break
            if item.url in existing:
                skipped += 1
                progress.tick_skipped()
                progress.emit(f"skip  {_trim(item.title)}")
                continue
            try:
                _insert(conn, item)
                existing.add(item.url)
                imported += 1
                progress.tick_imported()
                progress.emit(f"add   {_trim(item.title)}  [{item.last_visit:%Y-%m-%d %H:%M}]")
            except Exception as exc:
                failed += 1
                progress.tick_failed()
                progress.emit(f"error {_trim(str(exc))}")
        conn.commit()
    finally:
        conn.close()
    return imported, skipped, failed


def _trim(v, w=80):
    v = (v or "").replace("\n", " ").strip()
    return v if len(v) <= w else v[: w - 1] + "..."


def _insert(conn, item):
    micros = datetime_to_chromium_time(item.last_visit)
    conn.execute(
        "INSERT INTO urls (url, title, visit_count, typed_count, last_visit_time, hidden) "
        "VALUES (?, ?, ?, 0, ?, 0)",
        (item.url, item.title, item.visit_count, micros),
    )
    uid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.execute(
        "INSERT INTO visits (url, visit_time, from_visit, transition, segment_id, "
        "visit_duration, incremented_omnibox_typed_score, opener_visit) "
        "VALUES (?, ?, 0, 0, 0, 0, 0, 0)",
        (uid, micros),
    )


def _is_locked(path):
    probe = path.with_suffix(path.suffix + ".lockprobe")
    try:
        os.replace(path, probe)
        os.replace(probe, path)
        return False
    except OSError:
        try:
            if probe.exists():
                probe.unlink()
        except Exception:
            pass
        return True