__version__ = "0.3.0"
APP_NAME = "BrowserShift"
APP_TAGLINE = "Switch browsers. Keep your flow."